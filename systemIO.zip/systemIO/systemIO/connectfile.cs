﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace systemIO
{
    class Connectfile
    {
        public static void projectbyempID(string search, string filename, string filename2)
        {
            StreamReader reader = new StreamReader(filename2);
            string m_id = null, line, temp = "";
            while ((line = reader.ReadLine()) != null)
            { if (line.Substring(17, 3) == search)
                 {
                     m_id = line.Substring(17, 3);
                     temp = line;
                     break;
                 }
             }
             reader.Close();
             if (m_id == null)
             {
                 Console.WriteLine("Employee ID is not there");
             }
             else
             {
                 reader = new StreamReader(filename);
                 bool flag = true;
                 while ((line = reader.ReadLine()) != null)
                 {
                     if (line.Substring(17, 3) == m_id)
                     {
                         if (flag == true)
                         {
                             Console.WriteLine(" Manager ID is {0}", m_id);
                             Console.WriteLine("Employee Name".PadLeft(20) + " | " + "Employee ID".PadLeft(20) + " | " + "Department ID".PadLeft(20) +
                                                " | " + "Email".PadLeft(20) + " | " + "Phone".PadLeft(20) +
                                                " | " + "Project ID".PadLeft(20) + " | " + "Project Name".PadLeft(20) + " | " + "Manager ID".PadLeft(20));
                         }
                         flag = false;
                         Console.WriteLine(line + " | " + temp);
                     }
                 }
                 if (flag == true)
                 {
                     Console.WriteLine("Employee Id Not Matching with Manager ID");
                 }
                 reader.Close();
             }
         }
         public static void EmpInfobyDeptID(string search, string emppath, string deptpath)
         {
             StreamReader reader = new StreamReader(deptpath);
             string dept_id = null, line, temp = "";
             while ((line = reader.ReadLine()) != null)
             {
                 if (line.Substring(17, 3) == search)
                 {
                     temp = line;
                     dept_id = line.Substring(17, 3);
                     break;
                 }
             }
             reader.Close();
             if (dept_id == null)
                 Console.WriteLine("Department ID is not found in Department File");
             else
             {
                 reader = new StreamReader(emppath);
                 bool flag = true;
                 while ((line = reader.ReadLine()) != null)
                 {
                     if (line.Substring(40, 3) == dept_id)
                     {

                         if (flag == true)
                         {
                             Console.WriteLine("");
                             Console.WriteLine("Department ID is {0}", dept_id);
                             Console.WriteLine("Employee Name".PadLeft(20) + " | " + "Employee ID".PadLeft(20) + " | " + "Department ID".PadLeft(20) +
                                                " | " + "Email".PadLeft(20) + " | " + "Phone".PadLeft(20) + " | " + "Dept ID".PadLeft(20) +
                                                " | " + "Dept Name".PadLeft(20) + " | " + "No. of Proj".PadLeft(20));
                         }
                         flag = false;
                         Console.WriteLine(line + " | " + temp);
                         break;
                     }
                 }
                 if (flag == true)
                 {
                     Console.WriteLine("Department ID is not found in Employee file");
                 }
                 reader.Close();
             }
             
            }
        }
}
