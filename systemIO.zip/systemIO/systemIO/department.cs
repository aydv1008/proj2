﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace systemIO
{
    class department
    {
        public int dept_id, no_of_projects;
        public string dept_name;
        public department()
        {
            Console.WriteLine("enter department id (3 digits)");
            dept_id = int.Parse(Console.ReadLine());

            Console.WriteLine("enter department name");
            dept_name = Console.ReadLine();

            Console.WriteLine("enter number of projects");
            no_of_projects = int.Parse(Console.ReadLine());

        }
        public string displaydep()
        {
            return (dept_id.ToString().PadLeft(20) + " | " + dept_name.PadLeft(20) + " | " + no_of_projects.ToString().PadLeft(20));
        }
    }
}
